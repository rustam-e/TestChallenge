/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { NotificationFormComponent } from './notification-form.component';

describe('NotificationFormComponent', () => {
  beforeEach(() => {
    this.component = new NotificationFormComponent();
  });

  it('should create', () => {
    expect(this.component).toBeTruthy();
  });
});