export class Notification {
	constructor(
		public id: number,
	    public header: string,
	    public body: string,
	    public category: string
    ) { }
}
